package com.enaya.assistant

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale

class ListeningService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var recognizerIntent: Intent
    private var tts: TextToSpeech? = null
    private var pendingContact: ContactMatch? = null
    private var isStopping = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Listening for Hey Enaya"))
        tts = TextToSpeech(this, this)
        setupRecognizer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_CONFIRM -> pendingContact?.let { executeCall(it) }
            ACTION_CANCEL -> cancelPending()
            else -> startListening()
        }
        return START_STICKY
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            broadcastStatus("Speech recognition is not available", false)
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
        recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        }
    }

    private fun startListening() {
        if (isStopping) return
        try {
            recognizer?.cancel()
            recognizer?.startListening(recognizerIntent)
            broadcastStatus(if (pendingContact == null) "Listening… Say Hey Enaya" else "Say yes or no", true)
        } catch (_: Exception) {
            scheduleRestart()
        }
    }

    private fun processText(text: String) {
        broadcastHeard(text)
        val pending = pendingContact
        if (pending != null) {
            when {
                VoiceCommandParser.isYes(text) -> executeCall(pending)
                VoiceCommandParser.isNo(text) -> cancelPending()
            }
            return
        }

        if (!VoiceCommandParser.isWakeCommand(text)) return
        val contactName = VoiceCommandParser.extractContactName(text) ?: run {
            speak("কার নাম বলবেন?")
            return
        }
        val match = ContactRepository(this).findBestMatch(contactName)
        if (match == null) {
            speak("$contactName নামে কোনো কন্টাক্ট পাওয়া যায়নি")
            broadcastStatus("Contact not found: $contactName", true)
            return
        }
        pendingContact = match
        broadcastContact(match)
        speak("${match.name} কে কল করব? হ্যাঁ অথবা না বলুন")
        broadcastStatus("Waiting for confirmation", true)
    }

    private fun executeCall(contact: ContactMatch) {
        pendingContact = null
        broadcastContactCleared()
        speak("${contact.name} কে কল করা হচ্ছে")
        if (!CallManager.call(this, contact.number)) {
            broadcastStatus("Phone permission is required", true)
        }
        scheduleRestart(1600)
    }

    private fun cancelPending() {
        pendingContact = null
        broadcastContactCleared()
        speak("কল বাতিল করা হয়েছে")
        broadcastStatus("Call cancelled", true)
        scheduleRestart(800)
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "enaya-${System.currentTimeMillis()}")
    }

    private fun scheduleRestart(delay: Long = 650) {
        if (isStopping) return
        android.os.Handler(mainLooper).postDelayed({ startListening() }, delay)
    }

    override fun onResults(results: Bundle?) {
        val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!heard.isNullOrBlank()) processText(heard)
        scheduleRestart()
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val heard = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!heard.isNullOrBlank()) broadcastHeard(heard)
    }

    override fun onError(error: Int) {
        if (!isStopping) scheduleRestart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 500)
    }

    override fun onReadyForSpeech(params: Bundle?) = Unit
    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() = Unit
    override fun onEvent(eventType: Int, params: Bundle?) = Unit

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("bn", "BD"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.US
            }
        }
    }

    override fun onDestroy() {
        isStopping = true
        recognizer?.cancel()
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        broadcastStatus("Assistant is offline", false)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, ListeningService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_enaya)
            .setContentTitle("Enaya Assistant")
            .setContentText(text)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Enaya listening", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun broadcastStatus(text: String, active: Boolean) = sendBroadcast(
        Intent(ACTION_STATUS).setPackage(packageName)
            .putExtra(EXTRA_TEXT, text).putExtra(EXTRA_ACTIVE, active)
    )
    private fun broadcastHeard(text: String) = sendBroadcast(
        Intent(ACTION_HEARD).setPackage(packageName).putExtra(EXTRA_TEXT, text)
    )
    private fun broadcastContact(contact: ContactMatch) = sendBroadcast(
        Intent(ACTION_CONTACT).setPackage(packageName)
            .putExtra(EXTRA_NAME, contact.name).putExtra(EXTRA_NUMBER, contact.number)
    )
    private fun broadcastContactCleared() = sendBroadcast(Intent(ACTION_CONTACT_CLEARED).setPackage(packageName))

    companion object {
        const val ACTION_STOP = "com.enaya.assistant.STOP"
        const val ACTION_CONFIRM = "com.enaya.assistant.CONFIRM"
        const val ACTION_CANCEL = "com.enaya.assistant.CANCEL"
        const val ACTION_STATUS = "com.enaya.assistant.STATUS"
        const val ACTION_HEARD = "com.enaya.assistant.HEARD"
        const val ACTION_CONTACT = "com.enaya.assistant.CONTACT"
        const val ACTION_CONTACT_CLEARED = "com.enaya.assistant.CONTACT_CLEARED"
        const val EXTRA_TEXT = "text"
        const val EXTRA_ACTIVE = "active"
        const val EXTRA_NAME = "name"
        const val EXTRA_NUMBER = "number"
        private const val CHANNEL_ID = "enaya_listening"
        private const val NOTIFICATION_ID = 1047
    }
}
