package com.enaya.assistant

object VoiceCommandParser {
    private val wakeWords = listOf("hey enaya", "hi enaya", "enaya", "হেই এনায়া", "এনায়া", "হে এনায়া")
    private val callWords = listOf("calling", "call", "কল করো", "কল দাও", "ফোন করো", "ফোন দাও", "কলিং")
    private val yesWords = listOf("yes", "yeah", "confirm", "call now", "হ্যাঁ", "হ্যা", "করো", "কল দাও")
    private val noWords = listOf("no", "cancel", "stop", "না", "বাতিল", "থামো")

    fun extractContactName(raw: String): String? {
        var text = normalize(raw)
        wakeWords.forEach { text = text.replace(it, " ") }

        val marker = callWords.firstOrNull { text.contains(it) } ?: return null
        text = text.substringAfter(marker).trim()

        val noise = listOf("to", "please", "কে", "কো", "দয়া করে", "দাও", "করো")
        noise.forEach { text = text.replace(Regex("\\b${Regex.escape(it)}\\b"), " ") }
        return text.replace(Regex("\\s+"), " ").trim().takeIf { it.length >= 2 }
    }

    fun isWakeCommand(raw: String): Boolean {
        val text = normalize(raw)
        return wakeWords.any { text.contains(it) } && callWords.any { text.contains(it) }
    }

    fun isYes(raw: String): Boolean {
        val text = normalize(raw)
        return yesWords.any { text == it || text.contains(it) }
    }

    fun isNo(raw: String): Boolean {
        val text = normalize(raw)
        return noWords.any { text == it || text.contains(it) }
    }

    private fun normalize(text: String): String = text.lowercase()
        .replace(Regex("[^a-z0-9অ-হঀ-৿+ ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}
