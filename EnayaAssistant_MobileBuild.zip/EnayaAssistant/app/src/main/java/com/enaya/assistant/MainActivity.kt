package com.enaya.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.enaya.assistant.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var active = false
    private lateinit var pulseX: ObjectAnimator
    private lateinit var pulseY: ObjectAnimator

    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val essentialGranted = listOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        ).all { grants[it] == true || ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        if (essentialGranted) startAssistant() else binding.statusText.text = "Permissions were not granted"
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ListeningService.ACTION_STATUS -> {
                    active = intent.getBooleanExtra(ListeningService.EXTRA_ACTIVE, false)
                    binding.statusText.text = intent.getStringExtra(ListeningService.EXTRA_TEXT) ?: ""
                    updateUi()
                }
                ListeningService.ACTION_HEARD -> {
                    val text = intent.getStringExtra(ListeningService.EXTRA_TEXT).orEmpty()
                    binding.heardText.text = if (text.isBlank()) "Say: Hey Enaya, call Rafi" else "Heard: “$text”"
                }
                ListeningService.ACTION_CONTACT -> {
                    binding.contactName.text = intent.getStringExtra(ListeningService.EXTRA_NAME)
                    binding.contactNumber.text = intent.getStringExtra(ListeningService.EXTRA_NUMBER)
                    binding.confirmPanel.visibility = View.VISIBLE
                }
                ListeningService.ACTION_CONTACT_CLEARED -> binding.confirmPanel.visibility = View.GONE
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupPulse()
        binding.toggleButton.setOnClickListener {
            if (active) stopAssistant() else requestAndStart()
        }
        binding.callButton.setOnClickListener { sendServiceAction(ListeningService.ACTION_CONFIRM) }
        binding.cancelButton.setOnClickListener { sendServiceAction(ListeningService.ACTION_CANCEL) }
        updateUi()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(ListeningService.ACTION_STATUS)
            addAction(ListeningService.ACTION_HEARD)
            addAction(ListeningService.ACTION_CONTACT)
            addAction(ListeningService.ACTION_CONTACT_CLEARED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(receiver, filter)
    }

    override fun onStop() {
        unregisterReceiver(receiver)
        super.onStop()
    }

    private fun requestAndStart() {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startAssistant() else permissionsLauncher.launch(missing.toTypedArray())
    }

    private fun startAssistant() {
        val intent = Intent(this, ListeningService::class.java)
        ContextCompat.startForegroundService(this, intent)
        active = true
        binding.statusText.text = "Starting Enaya…"
        updateUi()
    }

    private fun stopAssistant() {
        sendServiceAction(ListeningService.ACTION_STOP)
        active = false
        binding.statusText.text = "Assistant is offline"
        binding.confirmPanel.visibility = View.GONE
        updateUi()
    }

    private fun sendServiceAction(action: String) {
        startService(Intent(this, ListeningService::class.java).setAction(action))
    }

    private fun setupPulse() {
        pulseX = ObjectAnimator.ofFloat(binding.orbGlow, View.SCALE_X, 0.93f, 1.06f).apply {
            duration = 900; repeatMode = ObjectAnimator.REVERSE; repeatCount = ObjectAnimator.INFINITE
        }
        pulseY = ObjectAnimator.ofFloat(binding.orbGlow, View.SCALE_Y, 0.93f, 1.06f).apply {
            duration = 900; repeatMode = ObjectAnimator.REVERSE; repeatCount = ObjectAnimator.INFINITE
        }
    }

    private fun updateUi() {
        binding.toggleButton.text = if (active) getString(R.string.stop_listening) else getString(R.string.start_listening)
        if (active) {
            if (!pulseX.isStarted) { pulseX.start(); pulseY.start() }
            binding.orbGlow.alpha = 1f
        } else {
            pulseX.cancel(); pulseY.cancel()
            binding.orbGlow.scaleX = 1f; binding.orbGlow.scaleY = 1f
            binding.orbGlow.alpha = 0.55f
        }
    }
}
