# Enaya Assistant v1

Neon red + black Android voice calling assistant.

## Features
- Voice command examples: `Hey Enaya, call Rafi`, `হেই এনায়া, আম্মুকে কল দাও`
- Searches Android Contacts
- Voice and on-screen confirmation before calling
- Direct phone call with CALL_PHONE permission
- Foreground microphone service and persistent notification
- Bengali/English command parser

## Build
1. Install Android Studio (JDK 17).
2. Open the `EnayaAssistant` folder.
3. Let Gradle sync.
4. Connect the Infinix phone with USB debugging, then Run; or use **Build > Build APK(s)**.
5. Install the APK and grant Microphone, Contacts, Phone and Notification permissions.

## Infinix/XOS settings
- Settings > Apps > Enaya Assistant > Battery > Unrestricted / Don't optimize
- Allow Auto-start and Background activity if XOS exposes those switches
- Keep the persistent “Enaya listening” notification enabled

## Important technical note
Android's built-in SpeechRecognizer is used in this MVP. It is practical for testing but Android documentation says it is not designed for uninterrupted, always-on recognition. For a production-grade low-power wake word, replace the recognizer loop with an on-device wake-word engine or deploy Enaya as the device's selected VoiceInteractionService where the phone supports it.
